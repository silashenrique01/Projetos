package br.edu.ifsp.aula03_ADID6;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Aula03Adid6ApplicationTests {

	@Test
	void contextLoads() {
	}

}
