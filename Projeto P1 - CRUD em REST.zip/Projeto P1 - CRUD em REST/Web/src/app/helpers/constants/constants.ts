export class Constants {
    static readonly DATE_FMT = 'd De MMMM De y';
    static readonly DATE_TIME_FMT = `${Constants.DATE_FMT}`;
  }
