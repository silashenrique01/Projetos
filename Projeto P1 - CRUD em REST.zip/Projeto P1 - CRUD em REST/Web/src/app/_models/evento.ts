export interface Evento {
   evento_id: number;
	 local:string;
	 data_evento:string;
	 tema:string;
	 quantidade_pessoas: number;
	 telefone: string;
	 email:string;
}
