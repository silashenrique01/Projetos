# Projeto P1 - Aplicações Distribuidas

## OBS: 
É necessário instalar o Node.js e o Angular CLI para executar o front end
Para isso, utilize os comandos abaixo:

Node.js -> https://nodejs.org/en/download/

Angular CLI -> npm i @angular/cli 
## Web

Navegue até a pasta do projeto web e digite `npm i`, após instalar o node_modules digite, `ng serve` no terminal para executar o front end. Navegue para `http://localhost:4200/`.
